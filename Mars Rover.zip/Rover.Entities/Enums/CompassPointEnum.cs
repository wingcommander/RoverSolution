﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Mars.Entities.Enums
{
    public enum  CompassPointEnum
    {
        N =0,
        E =1,
        S = 2,
        W =3
    }
}
