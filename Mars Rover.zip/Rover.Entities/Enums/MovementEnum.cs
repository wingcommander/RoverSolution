﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Mars.Entities.Enums
{
    public enum MovementEnum
    {
        L = 0,
        R = 1,
        M = 2      
    }
}
